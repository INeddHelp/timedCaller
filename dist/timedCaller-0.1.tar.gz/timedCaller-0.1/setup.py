from setuptools import setup

setup(
    name='timedCaller',
    version='v0.1',
    packages=["timedCaller"],
)
